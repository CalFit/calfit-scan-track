// Ce fichier réexporte simplement les fonctions du hook
import { useToast, toast } from "@/hooks/use-toast";

export { useToast, toast };
